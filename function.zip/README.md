# lambda-function

a description of how to use your lambda.

I will let ya know what I get my head wrapped around everything.

a description of any issues you encountered during deployment of this lambda.

I am having some configuration issues (my access key is not being recognized so I need to figure out how to reset that). I also realiszed in trying to troubleshoot that that I had two different regions set for each bucket but don't have the permission to delete the bucket that isn't empty so I need to figure out how to chagne those permissions. It is 11pm so at this point I am hanging this up until the morning.

an image and thumbnail that your Lambda processed:

